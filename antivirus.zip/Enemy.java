public class Enemy extends Entity {
    protected int tipo, defesa;    

    public Enemy(int linha, int coluna, int dano, int tipo, int defesa) {
        super(linha, coluna, dano);
        this.tipo = tipo;
        setDefesa(defesa);
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public int getDefesa() {
        return defesa;
    }

    public void setDefesa(int defesa) {
        if (defesa < 0 || defesa > 3) {
            throw new IllegalArgumentException("A defesa do inimigo deve estar entre 0 e 3.");
        }
        this.defesa = defesa;
    }

}


